package LLDProjects.PenDesign.Strategies.WriteStrategies;

public interface WriteBehaviour {
    void write();
}
