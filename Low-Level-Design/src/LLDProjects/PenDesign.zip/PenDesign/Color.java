package LLDProjects.PenDesign;

public enum Color {
    RED,
    BLUE,
    GREEN,
    BLACK
}
