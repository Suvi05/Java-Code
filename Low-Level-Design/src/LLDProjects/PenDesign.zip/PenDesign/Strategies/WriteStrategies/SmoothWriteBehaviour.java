package LLDProjects.PenDesign.Strategies.WriteStrategies;

public class SmoothWriteBehaviour implements WriteBehaviour {
    @Override
    public void write() {
        System.out.println("Writing Smoothly");
    }
}
