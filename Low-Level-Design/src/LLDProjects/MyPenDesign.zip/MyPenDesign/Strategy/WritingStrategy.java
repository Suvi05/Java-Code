package LLDProjects.MyPenDesign.Strategy;

public interface WritingStrategy {
    void write();
}
