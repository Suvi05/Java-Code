package Lectures.DesingPatterns.StructuralDP.FlyWeight.BeforeVersion;

public enum BulletStatus {
    FIRED,
    NOT_FIRED
}
