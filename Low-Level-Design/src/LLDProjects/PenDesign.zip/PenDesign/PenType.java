package LLDProjects.PenDesign;

public enum PenType {
    GEL,
    BALL,
    FOUNTAIN,
    MARKER
}
