package LLDProjects.PenDesign;

public class Refill {

    //We can add Ink and Tip classes here and can extend the code.
}
