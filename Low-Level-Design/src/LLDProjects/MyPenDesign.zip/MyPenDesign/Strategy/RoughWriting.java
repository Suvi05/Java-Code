package LLDProjects.MyPenDesign.Strategy;

public class RoughWriting implements WritingStrategy{

    @Override
    public void write() {
        System.out.println("Rough Writing Pen");
    }
}
