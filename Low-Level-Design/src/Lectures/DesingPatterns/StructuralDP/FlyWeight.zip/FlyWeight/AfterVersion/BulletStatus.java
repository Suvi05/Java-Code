package Lectures.DesingPatterns.StructuralDP.FlyWeight.AfterVersion;

public enum BulletStatus {
    FIRED,
    NOT_FIRED
}
