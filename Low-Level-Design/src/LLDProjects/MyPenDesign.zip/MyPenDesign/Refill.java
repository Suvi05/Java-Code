package LLDProjects.MyPenDesign;

public interface Refill {
    void checkRefilStatus();
    void isRefilCanChange();
    void changeRefil();
}
