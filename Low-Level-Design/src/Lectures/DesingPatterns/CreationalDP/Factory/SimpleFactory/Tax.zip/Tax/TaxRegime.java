package Lectures.DesingPatterns.CreationalDP.Factory.SimpleFactory.Tax;

public enum TaxRegime {
    OLD,
    NEW
}
