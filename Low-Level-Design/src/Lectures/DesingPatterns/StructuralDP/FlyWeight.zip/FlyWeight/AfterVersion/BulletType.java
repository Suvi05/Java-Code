package Lectures.DesingPatterns.StructuralDP.FlyWeight.AfterVersion;

public enum BulletType {
    FIVE_MM,
    SEVEN_MM,
    NINE_MM
}
