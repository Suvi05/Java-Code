package Lectures.DesingPatterns.CreationalDP.Factory.SimpleFactory.Tax;

import Lectures.DesingPatterns.CreationalDP.Factory.SimpleFactory.Tax.Algorithm.TaxAlgorithm;
import Lectures.DesingPatterns.CreationalDP.Factory.SimpleFactory.Tax.Algorithm.TaxCalculatorFactory;

public class Client {
    TaxAlgorithm taxAlgorithm= TaxCalculatorFactory.getTaxAlgorithm(TaxRegime.NEW);
    taxAlgorithm.calculateTax();
}
