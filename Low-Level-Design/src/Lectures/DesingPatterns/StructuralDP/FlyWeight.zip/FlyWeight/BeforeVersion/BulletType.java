package Lectures.DesingPatterns.StructuralDP.FlyWeight.BeforeVersion;

public enum BulletType {
    FIVE_MM,
    SEVEN_MM,
    NINE_MM
}
