package LLDProjects.MyPenDesign;

public enum Type {
    BALL,
    GEL,
    FOUNTAIN,
    INK
}
